from flask import Flask, request, jsonify
import os, requests

app = Flask(__name__)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-6.2-sol")

@app.get("/health")
def health():
    return jsonify(ok=True, model=MODEL)

@app.post("/chat")
def chat():
    if not OPENAI_API_KEY:
        return jsonify(reply="Backend ainda não foi configurado com uma chave de API por um adulto responsável."), 503
    data = request.get_json(force=True) or {}
    message = str(data.get("message", ""))[:4000]
    context = str(data.get("world_context", ""))[:5000]
    instructions = (
        "Você é ChatGPT, companheiro do jogador em Minecraft Java 1.20.1. Converse em português brasileiro, "
        "de forma natural, como parceiro de aventura. Use o contexto do jogo para responder. "
        "Você ainda não controla diretamente o jogo: não diga que executou ações. Sugira ações claramente como sugestões. "
        "Não invente blocos, mobs ou itens que não estejam no contexto."
    )
    payload = {"model": MODEL, "instructions": instructions,
               "input": f"Contexto do mundo:\n{context}\n\nMensagem do jogador:\n{message}",
               "max_output_tokens": 500}
    try:
        r = requests.post("https://api.openai.com/v1/responses", json=payload,
                         headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}, timeout=75)
        r.raise_for_status()
        response = r.json()
        text = "".join(part.get("text", "") for item in response.get("output", []) if item.get("type") == "message" for part in item.get("content", []) if part.get("type") == "output_text")
        return jsonify(reply=text or "A resposta veio vazia.")
    except Exception as exc:
        return jsonify(reply=f"Erro ao chamar o modelo: {exc}"), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8787")))

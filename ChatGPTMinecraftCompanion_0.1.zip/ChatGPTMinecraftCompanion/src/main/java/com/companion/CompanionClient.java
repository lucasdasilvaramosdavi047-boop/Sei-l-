package com.companion;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;

public class CompanionClient implements ClientModInitializer {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    // Replace with the Codespaces forwarded backend URL (HTTPS). Keep this URL private if the backend is private.
    private static volatile String backendUrl = "http://127.0.0.1:8787/chat";

    @Override public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("gpt")
                .then(argument("message", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        String message = StringArgumentType.getString(ctx, "message");
                        MinecraftClient client = MinecraftClient.getInstance();
                        if (client.player == null || client.world == null) return 0;
                        String context = buildWorldContext(client);
                        client.player.sendMessage(Text.literal("[ChatGPT] Enviando contexto do mundo..."), false);
                        CompletableFuture.runAsync(() -> requestChat(message, context, client));
                        return 1;
                    })));
            dispatcher.register(literal("gpturl")
                .then(argument("url", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        backendUrl = StringArgumentType.getString(ctx, "url").trim();
                        MinecraftClient.getInstance().execute(() -> {
                            if (MinecraftClient.getInstance().player != null)
                                MinecraftClient.getInstance().player.sendMessage(Text.literal("[ChatGPT] Endpoint atualizado."), false);
                        });
                        return 1;
                    })));
        });
    }

    private static String buildWorldContext(MinecraftClient c) {
        var p = c.player;
        var w = c.world;
        StringBuilder s = new StringBuilder();
        s.append("Minecraft 1.20.1. Contexto atual do jogador:\n");
        s.append("Nome: ").append(p.getName().getString()).append("\n");
        s.append("Dimensão: ").append(w.getRegistryKey().getValue()).append("\n");
        s.append(String.format("Posição: x=%.1f y=%.1f z=%.1f\n", p.getX(), p.getY(), p.getZ()));
        s.append(String.format("Vida: %.1f; fome: %d\n", p.getHealth(), p.getHungerManager().getFoodLevel()));
        s.append("Item na mão: ").append(p.getMainHandStack().isEmpty() ? "mão vazia" : p.getMainHandStack().getName().getString()).append("\n");
        s.append("Inventário (itens presentes): ");
        for (int i = 0; i < p.getInventory().size(); i++) {
            var stack = p.getInventory().getStack(i);
            if (!stack.isEmpty()) s.append(stack.getName().getString()).append(" x").append(stack.getCount()).append("; ");
        }
        return s.toString();
    }

    private static void requestChat(String message, String worldContext, MinecraftClient client) {
        try {
            String json = "{\"message\":\"" + escape(message) + "\",\"world_context\":\"" + escape(worldContext) + "\"}";
            HttpRequest request = HttpRequest.newBuilder(URI.create(backendUrl))
                .timeout(Duration.ofSeconds(90)).header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)).build();
            HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
            String reply = extractReply(response.body());
            client.execute(() -> {
                if (client.player != null) client.player.sendMessage(Text.literal("[ChatGPT] " + reply), false);
            });
        } catch (Exception e) {
            client.execute(() -> {
                if (client.player != null) client.player.sendMessage(Text.literal("[ChatGPT] Falha ao conectar: " + e.getMessage()), false);
            });
        }
    }

    private static String escape(String x) { return x.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r"); }
    // Backend returns simple JSON; this extracts the reply field and handles escaped newlines/quotes.
    private static String extractReply(String body) {
        int key = body.indexOf("\"reply\"");
        if (key < 0) return "Resposta do servidor: " + body;
        int colon = body.indexOf(':', key), start = body.indexOf('"', colon + 1);
        if (start < 0) return body;
        StringBuilder out = new StringBuilder(); boolean esc = false;
        for (int i = start + 1; i < body.length(); i++) {
            char ch = body.charAt(i);
            if (esc) { if (ch == 'n') out.append('\n'); else if (ch == 't') out.append('\t'); else out.append(ch); esc = false; }
            else if (ch == '\\') esc = true;
            else if (ch == '"') break;
            else out.append(ch);
        }
        return out.toString();
    }
}

# ChatGPT Minecraft Companion (Fabric 1.20.1)

Milestone 0.1: a client command `/gpt <message>` sends a short player/world context (dimension, coordinates, health, hunger, hand item, inventory list) to a private Python backend; backend calls the OpenAI Responses API and sends ChatGPT's response back to Minecraft chat.

## Build
Requires Java 17 and Gradle. In Codespaces, run `gradle build`. JAR is in `build/libs/`.

## Backend
`cd backend && pip install -r requirements.txt`
Set `OPENAI_API_KEY` as a backend environment secret (do not commit it, do not put it in the Minecraft mod). Optionally set `OPENAI_MODEL` (default `gpt-6.2-sol`).
Run `python app.py`; Codespaces port 8787 may be forwarded as HTTPS. Configure in Minecraft using `/gpturl https://YOUR-FORWARDED-URL/chat`, then `/gpt Olá, ChatGPT!`

The current milestone provides real ChatGPT conversation plus limited world context. It does not yet spawn a custom companion entity or execute movement/mining/building actions. Those are subsequent development milestones. Keep API credentials server-side and have a responsible adult supervise any account/API setup or billing.
